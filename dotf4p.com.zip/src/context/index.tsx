'use client';

import React, {
  createContext,
  useContext,
  useState,
  useEffect,
} from 'react';

interface NavigationContextType {
  activeCategory: string;
  setActiveCategory: (
    category: string,
  ) => void;
  searchQuery: string;
  setSearchQuery: (
    query: string,
  ) => void;
  isDarkMode: boolean;
  toggleTheme: () => void;
  largeThumbnails: boolean;
  toggleLargeThumbnails: () => void;
}

const NavigationContext = createContext<
  NavigationContextType | undefined
>(undefined);

export const NavigationProvider: React.FC<{
  children: React.ReactNode;
}> = ({ children }) => {
  const [
    activeCategory,
    setActiveCategory,
  ] = useState('recommended');
  const [searchQuery, setSearchQuery] =
    useState('');

  // Preferences
  const [isDarkMode, setIsDarkMode] =
    useState(() => {
      const savedTheme =
        localStorage.getItem('theme');
      if (savedTheme) {
        return savedTheme === 'dark';
      } else if (
        window.matchMedia &&
        window.matchMedia(
          '(prefers-color-scheme: dark)',
        ).matches
      ) {
        return true;
      } else {
        return false;
      }
    });
  const [
    largeThumbnails,
    setLargeThumbnails,
  ] = useState(false);

  // Update HTML class when theme changes
  useEffect(() => {
    const root =
      window.document.documentElement;
    if (isDarkMode) {
      root.classList.add('dark');
      localStorage.setItem(
        'theme',
        'dark',
      );
    } else {
      root.classList.remove('dark');
      localStorage.setItem(
        'theme',
        'light',
      );
    }
  }, [isDarkMode]);

  const toggleTheme = () =>
    setIsDarkMode((prev) => !prev);
  const toggleLargeThumbnails = () =>
    setLargeThumbnails((prev) => !prev);

  const handleSetCategory = (
    category: string,
  ) => {
    setActiveCategory(category);
    setSearchQuery('');
  };

  return (
    <NavigationContext.Provider
      value={{
        activeCategory,
        setActiveCategory:
          handleSetCategory,
        searchQuery,
        setSearchQuery,
        isDarkMode,
        toggleTheme,
        largeThumbnails,
        toggleLargeThumbnails,
      }}>
      {children}
    </NavigationContext.Provider>
  );
};

export const useNavigation = () => {
  const context = useContext(
    NavigationContext,
  );
  if (context === undefined) {
    throw new Error(
      'useNavigation must be used within a NavigationProvider',
    );
  }
  return context;
};
