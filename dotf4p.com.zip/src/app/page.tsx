'use client';

import React, {
  useState,
  useEffect,
} from 'react';
import { useNavigation } from '@/context';
import {
  MOCK_VIDEOS,
  CATEGORIES,
} from '@/lib/constants';
import { VideoItem } from '../types';
import { generateDynamicContent } from '@/lib/gemini';

import {
  Loader2,
  Zap,
} from 'lucide-react';
import VideoCard from '@/components/VideoCard';

export default function Page() {
  const {
    activeCategory,
    searchQuery,
    largeThumbnails,
  } = useNavigation();
  const [videos, setVideos] = useState<
    VideoItem[]
  >([]);
  const [loading, setLoading] =
    useState(false);
  const [isAiMode, setIsAiMode] =
    useState(false);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);

      // Handle Search Mode
      if (searchQuery) {
        await new Promise((resolve) =>
          setTimeout(resolve, 400),
        );
        const lowerQuery =
          searchQuery.toLowerCase();
        // Create a larger pool for search as well for demo purposes
        const searchPool = Array.from({
          length: 5,
        }).flatMap((_, i) =>
          MOCK_VIDEOS.map((v) => ({
            ...v,
            id: `${v.id}-search-${i}`,
          })),
        );
        const results =
          searchPool.filter(
            (v) =>
              v.title
                .toLowerCase()
                .includes(lowerQuery) ||
              v.source
                .toLowerCase()
                .includes(lowerQuery),
          );
        setVideos(results);
        setIsAiMode(false);
        setLoading(false);
        return;
      }

      // Handle Category Mode
      if (
        activeCategory === 'recommended'
      ) {
        await new Promise((resolve) =>
          setTimeout(resolve, 600),
        );
        // Generate ~50 videos for "roll down" effect
        const baseList = [
          ...MOCK_VIDEOS,
        ];
        const extendedList: VideoItem[] =
          [];

        // Repeat the list approx 7 times (8 * 7 = 56 items)
        for (let i = 0; i < 7; i++) {
          const chunk = baseList.map(
            (v) => ({
              ...v,
              id: `${v.id}-gen-${i}`,
              // Slightly randomize views for variety
              views: `${(Math.random() * 5 + 0.1).toFixed(1)}M`,
            }),
          );
          // Shuffle chunk
          extendedList.push(
            ...chunk.sort(
              () => 0.5 - Math.random(),
            ),
          );
        }

        setVideos(extendedList);
        setIsAiMode(false);
        setLoading(false);
        return;
      }

      // Filter local mock data
      const filteredLocal =
        MOCK_VIDEOS.filter(
          (v) =>
            v.category ===
            activeCategory,
        );

      // AI Logic
      const shouldUseAI =
        process.env.API_KEY &&
        (filteredLocal.length < 4 ||
          activeCategory === 'tech' ||
          activeCategory === 'gaming');

      if (shouldUseAI) {
        setIsAiMode(true);
        try {
          const aiVideos =
            await generateDynamicContent(
              activeCategory,
            );
          setVideos([
            ...filteredLocal,
            ...aiVideos,
          ]);
        } catch (e) {
          console.error(
            'Error generating AI content',
            e,
          );
          setVideos(filteredLocal);
        }
      } else {
        setIsAiMode(false);
        await new Promise((resolve) =>
          setTimeout(resolve, 500),
        );
        // Expand specific category content to ~40-50 items if possible, or just repeat
        const repeatedCategory = [];
        for (let i = 0; i < 6; i++) {
          if (
            filteredLocal.length > 0
          ) {
            repeatedCategory.push(
              ...filteredLocal.map(
                (v) => ({
                  ...v,
                  id: `${v.id}-cat-${i}`,
                }),
              ),
            );
          }
        }
        setVideos(
          repeatedCategory.length > 0
            ? repeatedCategory
            : [],
        );
      }

      setLoading(false);
    };

    fetchData();
  }, [activeCategory, searchQuery]);

  const currentCategoryName =
    searchQuery
      ? `Resultados para: "${searchQuery}"`
      : CATEGORIES.find(
          (c) =>
            c.slug === activeCategory,
        )?.name || 'Vídeos';

  // Dynamic Grid Class based on preferences
  const gridClass = largeThumbnails
    ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6'
    : 'grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4';

  return (
    <div className='container mx-auto p-4 max-w-450 pb-20'>
      {/* Header Section */}
      <div className='mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4'>
        <div>
          <h1 className='text-xl font-bold tracking-tight flex items-center gap-2'>
            {currentCategoryName}
            {isAiMode &&
              !searchQuery && (
                <span className='text-xs font-normal px-2 py-0.5 rounded-full border border-purple-500/30 bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center gap-1'>
                  <Zap className='w-3 h-3' />{' '}
                  Gerado por IA
                </span>
              )}
          </h1>
          <p className='text-sm text-gray-600 dark:text-gray-400 mt-1'>
            Exibindo {videos.length}{' '}
            vídeos.
          </p>
        </div>
      </div>

      {/* Grid */}
      {loading ? (
        <div className='flex h-96 w-full items-center justify-center'>
          <div className='flex flex-col items-center gap-3'>
            <Loader2 className='w-12 h-12 text-rose-500 animate-spin' />
            <span className='text-sm text-gray-500 animate-pulse font-medium'>
              Carregando feed
              infinito...
            </span>
          </div>
        </div>
      ) : videos.length > 0 ? (
        <div className={gridClass}>
          {videos.map((video) => (
            <VideoCard
              key={video.id}
              video={video}
            />
          ))}
        </div>
      ) : (
        <div className='flex h-96 w-full flex-col items-center justify-center text-gray-500 border-2 border-dashed border-black/5 dark:border-white/5 rounded-2xl bg-white/30 dark:bg-white/5'>
          <p className='text-xl font-semibold mb-2'>
            Ops! Nada por aqui.
          </p>
          <p className='text-sm'>
            Tente buscar por outro termo
            ou categoria.
          </p>
        </div>
      )}

      {/* Pagination / Loading More Trigger */}
      {!loading &&
        videos.length > 0 && (
          <div className='mt-16 flex flex-col items-center justify-center gap-4 text-gray-400'>
            <div className='h-1 w-24 bg-gray-300 dark:bg-white/10 rounded-full' />
            <p className='text-xs uppercase tracking-widest'>
              Fim dos resultados
            </p>
          </div>
        )}
    </div>
  );
}
