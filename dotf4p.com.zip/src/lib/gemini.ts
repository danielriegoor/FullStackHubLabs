import {
  GoogleGenAI,
  Type,
} from '@google/genai';
import { VideoItem } from '../types';

interface GeneratedVideoData {
  title: string;
  duration: string;
  views: string;
  source: string;
  publishedAt: string;
}

const ai = new GoogleGenAI({
  apiKey: process.env.API_KEY,
});

export const generateDynamicContent =
  async (
    category: string,
  ): Promise<VideoItem[]> => {
    try {
      const prompt = `Generate a list of 8 realistic video titles, durations, mock view counts, and source website names for the category: "${category}". 
    The content should be safe for work (SFW), interesting, and engaging. 
    Return the data as a JSON array.`;

      const response =
        await ai.models.generateContent(
          {
            model:
              'gemini-3-flash-preview',
            contents: prompt,
            config: {
              responseMimeType:
                'application/json',
              responseSchema: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: {
                      type: Type.STRING,
                    },
                    duration: {
                      type: Type.STRING,
                    },
                    views: {
                      type: Type.STRING,
                    },
                    source: {
                      type: Type.STRING,
                    },
                    publishedAt: {
                      type: Type.STRING,
                      description:
                        "e.g., '2 hours ago'",
                    },
                  },
                  required: [
                    'title',
                    'duration',
                    'views',
                    'source',
                    'publishedAt',
                  ],
                },
              },
            },
          },
        );

      const generatedData = JSON.parse(
        response.text || '[]',
      );

      // Transform into VideoItem
      return generatedData.map(
        (
          item: GeneratedVideoData,
          index: number,
        ) => ({
          id: `ai-${category}-${Date.now()}-${index}`,
          title: item.title,
          thumbnail: `https://picsum.photos/seed/${item.title.replace(/\s/g, '')}/400/225`,
          duration: item.duration,
          views: item.views,
          source: item.source,
          publishedAt: item.publishedAt,
          category: category,
          isAiGenerated: true,
        }),
      );
    } catch (error) {
      console.error(
        'Gemini generation failed:',
        error,
      );
      return [];
    }
  };
