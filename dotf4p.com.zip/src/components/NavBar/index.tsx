'use client';

import React, {
  useState,
  useRef,
  useEffect,
} from 'react';
import { ChevronDown } from 'lucide-react';
import { CATEGORIES } from '@/lib/constants';
import { useNavigation } from '@/context';

const NavBar: React.FC = () => {
  const {
    setActiveCategory,
    activeCategory,
  } = useNavigation();
  const [isCatOpen, setIsCatOpen] =
    useState(false);
  const catRef =
    useRef<HTMLDivElement>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(
      event: MouseEvent,
    ) {
      if (
        catRef.current &&
        !catRef.current.contains(
          event.target as Node,
        )
      ) {
        setIsCatOpen(false);
      }
    }
    document.addEventListener(
      'mousedown',
      handleClickOutside,
    );
    return () =>
      document.removeEventListener(
        'mousedown',
        handleClickOutside,
      );
  }, [catRef]);

  const navItems = [
    {
      label: 'Vídeos',
      action: () =>
        setActiveCategory(
          'recommended',
        ),
    },
    {
      label: 'Live cams',
      action: () => {},
    }, // Placeholder
    {
      label: 'AI chat',
      action: () => {},
    }, // Placeholder
    {
      label: 'Nossa rede',
      action: () => {},
    }, // Placeholder
  ];

  return (
    <div className='w-full bg-white dark:bg-dark-900 border-b border-gray-200 dark:border-white/5 relative z-40 transition-colors duration-300'>
      <div className='container mx-auto max-w-400 px-4'>
        <div className='flex items-center gap-6 py-3 text-sm font-medium text-gray-700 dark:text-gray-300 overflow-x-auto no-scrollbar'>
          {/* Static Item */}
          <button
            onClick={() =>
              setActiveCategory(
                'recommended',
              )
            }
            className='whitespace-nowrap hover:text-primary-500 transition-colors'>
            Vídeos
          </button>

          {/* Categories Dropdown */}
          <div
            className='relative'
            ref={catRef}>
            <button
              onClick={() =>
                setIsCatOpen(!isCatOpen)
              }
              className={`flex items-center gap-1 whitespace-nowrap hover:text-primary-500 transition-colors ${isCatOpen ? 'text-primary-500' : ''}`}>
              Categorias
              <ChevronDown
                className={`w-4 h-4 transition-transform ${isCatOpen ? 'rotate-180' : ''}`}
              />
            </button>

            {/* Dropdown Menu */}
            {isCatOpen && (
              <div className='absolute top-full left-0 mt-2 w-64 bg-white dark:bg-dark-800 rounded-md shadow-xl border border-gray-200 dark:border-white/10 overflow-hidden py-2 z-50'>
                {CATEGORIES.map(
                  (cat) => (
                    <button
                      key={cat.id}
                      onClick={() => {
                        setActiveCategory(
                          cat.slug,
                        );
                        setIsCatOpen(
                          false,
                        );
                      }}
                      className={`
                      w-full text-left px-4 py-2.5 hover:bg-gray-100 dark:hover:bg-white/5 flex items-center gap-3 transition-colors
                      ${activeCategory === cat.slug ? 'text-primary-500 bg-gray-50 dark:bg-white/5' : 'text-gray-700 dark:text-gray-300'}
                    `}>
                      <span className='text-gray-400 dark:text-gray-500'>
                        {cat.icon}
                      </span>
                      {cat.name}
                    </button>
                  ),
                )}
              </div>
            )}
          </div>

          {/* Other Static Items */}
          {navItems
            .slice(1)
            .map((item) => (
              <button
                key={item.label}
                onClick={item.action}
                className='whitespace-nowrap hover:text-primary-500 transition-colors'>
                {item.label}
              </button>
            ))}
        </div>
      </div>
    </div>
  );
};

export default NavBar;
