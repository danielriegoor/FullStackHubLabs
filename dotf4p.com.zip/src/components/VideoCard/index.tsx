import React, { useState } from 'react';
import { VideoItem } from '../types';
import {
  Play,
  Sparkles,
} from 'lucide-react';

interface VideoCardProps {
  video: VideoItem;
}

const VideoCard: React.FC<
  VideoCardProps
> = ({ video }) => {
  const [isHovered, setIsHovered] =
    useState(false);

  return (
    <div
      className='group relative flex flex-col gap-2 cursor-pointer'
      onMouseEnter={() =>
        setIsHovered(true)
      }
      onMouseLeave={() =>
        setIsHovered(false)
      }>
      {/* Thumbnail Container */}
      <div className='relative aspect-video w-full overflow-hidden rounded-lg bg-dark-800 shadow-md ring-1 ring-white/5 transition-all duration-300 group-hover:shadow-xl group-hover:ring-primary-500/50'>
        {/* Image */}
        <img
          src={video.thumbnail}
          alt={video.title}
          className={`h-full w-full object-cover transition-transform duration-700 ${isHovered ? 'scale-110' : 'scale-100'}`}
          loading='lazy'
        />

        {/* Overlay Gradient */}
        <div className='absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-60' />

        {/* Duration Badge */}
        <div className='absolute bottom-2 right-2 rounded bg-black/80 px-1.5 py-0.5 text-xs font-bold text-white backdrop-blur-sm'>
          {video.duration}
        </div>

        {/* AI Badge if generated */}
        {video.isAiGenerated && (
          <div className='absolute top-2 left-2 rounded bg-purple-600/90 px-1.5 py-0.5 text-[10px] font-bold text-white backdrop-blur-sm flex items-center gap-1'>
            <Sparkles className='w-3 h-3' />{' '}
            AI
          </div>
        )}

        {/* Play Icon Overlay (On Hover) */}
        <div
          className={`absolute inset-0 flex items-center justify-center bg-black/20 backdrop-blur-[2px] transition-opacity duration-300 ${isHovered ? 'opacity-100' : 'opacity-0'}`}>
          <div className='rounded-full bg-primary-600 p-3 shadow-lg shadow-primary-600/40 transform transition-transform duration-300 hover:scale-110'>
            <Play className='w-6 h-6 text-white fill-white' />
          </div>
        </div>
      </div>

      {/* Meta Info */}
      <div className='flex flex-col px-1'>
        <h3 className='line-clamp-2 text-sm font-semibold text-gray-100 group-hover:text-primary-400 transition-colors'>
          {video.title}
        </h3>
        <div className='mt-1 flex items-center justify-between text-xs text-gray-400'>
          <span className='font-medium text-gray-300'>
            {video.source}
          </span>
          <span>
            {video.views} •{' '}
            {video.publishedAt}
          </span>
        </div>
      </div>
    </div>
  );
};

export default VideoCard;
