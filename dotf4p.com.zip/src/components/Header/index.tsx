'use client';

import React, { useState } from 'react';
import {
  Search,
  Menu,
  User,
  Bell,
} from 'lucide-react';

interface HeaderProps {
  onMenuClick: () => void;
  onSearch: (query: string) => void;
}

const Header: React.FC<HeaderProps> = ({
  onMenuClick,
  onSearch,
}) => {
  const [query, setQuery] =
    useState('');

  const handleSearchSubmit = (
    e: React.FormEvent,
  ) => {
    e.preventDefault();
    onSearch(query);
  };

  return (
    <header className='fixed top-0 left-0 right-0 z-50 h-16 border-b border-white/5 bg-dark-900/80 backdrop-blur-md'>
      <div className='flex h-full items-center justify-between px-4 lg:px-6'>
        {/* Left: Logo & Menu */}
        <div className='flex items-center gap-4'>
          <button
            onClick={onMenuClick}
            className='rounded-lg p-2 text-gray-400 hover:bg-white/5 hover:text-white lg:hidden'>
            <Menu className='h-6 w-6' />
          </button>

          <div
            className='flex items-center gap-2 cursor-pointer'
            onClick={() =>
              window.location.reload()
            }>
            <div className='flex h-8 w-8 items-center justify-center rounded bg-primary-600 text-white font-bold'>
              A
            </div>
            <span className='text-xl font-bold tracking-tight text-white hidden sm:block'>
              Aggregat
              <span className='text-primary-500'>
                0
              </span>
              r
            </span>
          </div>
        </div>

        {/* Center: Search */}
        <div className='flex-1 max-w-2xl px-4 lg:px-12'>
          <form
            onSubmit={
              handleSearchSubmit
            }
            className='relative group'>
            <input
              type='text'
              placeholder='Pesquisar vídeos, canais ou URLs...'
              value={query}
              onChange={(e) =>
                setQuery(e.target.value)
              }
              className='w-full rounded-full border border-white/10 bg-dark-800 py-2.5 pl-10 pr-4 text-sm text-gray-200 placeholder-gray-500 focus:border-primary-500/50 focus:bg-dark-950 focus:outline-none focus:ring-1 focus:ring-primary-500/50 transition-all'
            />
            <Search className='absolute left-3.5 top-2.5 h-4 w-4 text-gray-500 group-focus-within:text-primary-400 transition-colors' />
          </form>
        </div>

        {/* Right: Actions */}
        <div className='flex items-center gap-2 sm:gap-4'>
          <button className='hidden sm:flex items-center justify-center rounded-full p-2 text-gray-400 hover:bg-white/5 hover:text-white transition-colors'>
            <Bell className='h-5 w-5' />
          </button>
          <button className='flex items-center gap-2 rounded-full bg-primary-600 px-4 py-1.5 text-sm font-medium text-white hover:bg-primary-500 transition-colors shadow-lg shadow-primary-600/20'>
            <User className='h-4 w-4' />
            <span className='hidden sm:inline'>
              Entrar
            </span>
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
